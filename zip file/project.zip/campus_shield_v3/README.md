<<<<<<< HEAD
# CAMPUS-SHEILD-
=======
# Campus Shield v3

Run with `python app.py` after installing requirements.
>>>>>>> 6a68845 (Initial Commit)
